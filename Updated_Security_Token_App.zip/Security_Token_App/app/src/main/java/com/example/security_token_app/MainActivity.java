package com.example.security_token_app;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity
{
    private static String SHARED_PREF_NAME = "SharedPrefFile";
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    private static String TIMESTAMP_KEY = "TIMESTAMP_KEY";
    private TextView countDownTextView;
    TextView passCodeTextView;
    static int passCode;
    static String currentDateTime;
    static ArrayList<String> arrayIntegerList = new ArrayList<String>();
    Button verifyButton;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        countDownTextView = (TextView)findViewById(R.id.textView4_time_remaining);
        passCodeTextView= (TextView)findViewById(R.id.textView3_passCode_int);
        verifyButton = (Button)findViewById(R.id.button1);
        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME,MODE_PRIVATE);
        editor = sharedPreferences.edit();

        String check = sharedPreferences.getString(TIMESTAMP_KEY, null);
        if(check != null) //might be the boolean is not saved in shared pref
        {
            //MainActivity2.restoreTimeStamp();
            MainActivity2.adapter.add(check);
            Toast.makeText(getBaseContext(), "restored", Toast.LENGTH_SHORT).show();
            openSecondaryActivity();  //switched this and bottom


        }
        createPassCode();
            new CountDownTimer(60000, 1000)
            {
                @Override
                public void onTick(long timeUntillFinished)
                {
                    countDownTextView.setText("seconds remaining: " + timeUntillFinished / 1000 % 60);
                }

                @Override
                public void onFinish()
                {
                    createPassCode();
                    start();
                }
            }.start();
            verifyButton.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    openSecondaryActivity();
                }
            });
    }
    public void createPassCode()
    {
        int minute = Calendar.getInstance().get(Calendar.MINUTE);
        passCode=minute*1245 + 10000;
        String timeStamp = getTimeStamp();
        arrayIntegerList.add(timeStamp);
        String passCodeStr = Integer.toString(passCode);
        passCodeTextView.setText(passCodeStr);
    }

    public void openSecondaryActivity()
    {
        Intent intent = new Intent(this, MainActivity2.class);
        startActivity(intent);
    }

    public static int getPassCode()
    {
        return passCode;
    }

    public static String getTimeStamp()
    {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        currentDateTime = dateFormat.format(new Date());
        return currentDateTime;
    }
}