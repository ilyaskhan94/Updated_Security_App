package com.example.security_token_app;
import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity
{
    static SharedPreferences sharedPreferences;
    private static String SHARED_PREF_NAME = "SharedPrefFile";
    private static String TIMESTAMP_KEY = "TIMESTAMP_KEY";
    ArrayList<String> arrayList = new ArrayList<String>();
    ListView listView;
    Button clearButton;
    int count;
    String item;
    static ArrayAdapter<String> adapter;
    static boolean isSaved = false;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        listView = (ListView) findViewById(R.id.listView1);
        clearButton = (Button) findViewById(R.id.passButton);
        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME,MODE_PRIVATE);
        if(isSaved==false)
        {
            for (String temp : MainActivity.arrayIntegerList)
            {
                arrayList.add(temp);
            }
        }

        if(isSaved==false)
        {
            adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, arrayList);
            listView.setAdapter(adapter);
        }
        isSaved=false;

        clearButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                count = adapter.getCount();
                item = adapter.getItem(count-1);
                adapter.clear();
                adapter.add(item);
                saveTimeStamp();
            }
        });
    }

    public void saveTimeStamp()
    {
        int i = adapter.getCount();
        if(isSaved==true)
        {
            isSaved=false;
            return;
        }
        String lastTimeStamp = adapter.getItem(i-1);
        if(!lastTimeStamp.isEmpty())
        {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString(SHARED_PREF_NAME, lastTimeStamp);
            editor.apply();
            Toast.makeText(getBaseContext(), "time stamp saved", Toast.LENGTH_SHORT).show();
            isSaved = true;
        }
        else
        {
            Toast.makeText(getBaseContext(), "nothing saved", Toast.LENGTH_SHORT).show();
            return;
        }
    }

    public static void restoreTimeStamp()
    {
        String check = sharedPreferences.getString(TIMESTAMP_KEY, null);
        if(check != null) //might be the boolean is not saved in shared pref
        {
            String lastTimeStamp = sharedPreferences.getString(TIMESTAMP_KEY, null);
            adapter.add(lastTimeStamp);
        }
    }
}